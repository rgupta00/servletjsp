function validate(){
    isValid=true;
    var phoneRE = /^[2-9]{2}[0-9]{8}$/;
    let pNo =document.getElementById("pNo").value;
   if(!pNo.match(phoneRE)){
       alert('no is not phone no');
       isValid=false;
   }
    
 return isValid;
 }
 